    // tailwind.config.js
    module.exports = {
      content: [],
      theme: {
        extend: {},
      },
      plugins: [],
    };